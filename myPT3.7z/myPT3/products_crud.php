<?php
 
include_once 'database.php';
 
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
//Create
if(isset($_POST['create'])){
  if($_SESSION['user level']=='supervisor' || $_SESSION['user level']=='admin'){
  try {
 
      $stmt = $conn->prepare("INSERT INTO tbl_products_a165433_pt2(fld_product_num,
        fld_product_name, fld_product_price, fld_product_food, fld_product_cage,
        fld_product_description, fld_product_quantity) VALUES(:pid, :name, :price, :food,
        :cage, :description, :quantity)");
     
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
      $stmt->bindParam(':name', $name, PDO::PARAM_STR);
      $stmt->bindParam(':price', $price, PDO::PARAM_INT);
      $stmt->bindParam(':food', $food, PDO::PARAM_STR);
      $stmt->bindParam(':cage', $cage, PDO::PARAM_STR);
      $stmt->bindParam(':description', $description, PDO::PARAM_STR);
      $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
       
    $pid = $_POST['pid'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $food =  $_POST['food'];
    $cage = $_POST['cage'];
    $description = $_POST['description'];
    $quantity = $_POST['quantity'];
     
    $stmt->execute();
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}else{
    $message = "You have no right to make a change on this!";
    echo "<script type='text/javascript'>alert('$message');";
    echo "window.location.href = 'products.php';";
    echo "</script>";
  }

}
 
//Update
if(isset($_POST['update'])){
  if($_SESSION['user level']=='supervisor' || $_SESSION['user level']=='admin'){
    
  try {
 
      $stmt = $conn->prepare("UPDATE tbl_products_a165433_pt2 SET fld_product_num = :pid,
        fld_product_name = :name, fld_product_price = :price, fld_product_food = :food,
        fld_product_cage = :cage, fld_product_description = :description, fld_product_quantity = :quantity
        WHERE fld_product_num = :oldpid");
     
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
      $stmt->bindParam(':name', $name, PDO::PARAM_STR);
      $stmt->bindParam(':price', $price, PDO::PARAM_INT);
      $stmt->bindParam(':food', $food, PDO::PARAM_STR);
      $stmt->bindParam(':cage', $cage, PDO::PARAM_STR);
      $stmt->bindParam(':description', $description, PDO::PARAM_STR);
      $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
      $stmt->bindParam(':oldpid', $oldpid, PDO::PARAM_STR);
       
    $pid = $_POST['pid'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $food =  $_POST['food'];
    $cage = $_POST['cage'];
    $description = $_POST['description'];
    $quantity = $_POST['quantity'];
    $oldpid = $_POST['oldpid'];
     
    $stmt->execute();
 
    header("Location: products.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }

}else{
    $message = "You have no right to make a change on this!";
    echo "<script type='text/javascript'>alert('$message');";
    echo "window.location.href = 'products.php';";
    echo "</script>";
  }

}
 
//Delete
if(isset($_GET['delete'])){
  if($_SESSION['user level']=='supervisor' || $_SESSION['user level']=='admin'){
  try {
 
      $stmt = $conn->prepare("DELETE FROM tbl_products_a165433_pt2 WHERE fld_product_num = :pid");
     
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
       
    $pid = $_GET['delete'];
     
    $stmt->execute();
 
    header("Location: products.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}else{
    $message = "You have no right to make a change on this!";
    echo "<script type='text/javascript'>alert('$message');";
    echo "window.location.href = 'products.php';";
    echo "</script>";
  }

}
 
//Edit
if(isset($_GET['edit'])){
  if($_SESSION['user level']=='supervisor' || $_SESSION['user level']=='admin'){
    try {
 
      $stmt = $conn->prepare("SELECT * FROM tbl_products_a165433_pt2 WHERE fld_product_num = :pid");
     
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
       
    $pid = $_GET['edit'];
     
    $stmt->execute();
 
    $editrow = $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
  }else{
    $message = "You have no right to make a change on this!";
    echo "<script type='text/javascript'>alert('$message');";
    echo "window.location.href = 'products.php';";
    echo "</script>";
  }
}
 
  $conn = null;
?>