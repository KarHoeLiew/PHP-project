<!DOCTYPE html>
<html>
<head>
  <title>DesBirds : HomePage</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <link href="https://fonts.googleapis.com/css?family=Lato:400,700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/036f0d3373.js" crossorigin="anonymous"></script>
  <style type="text/css">
    body{
      background: url(https://images.unsplash.com/photo-1535129991172-d042d9834e49?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=967&q=80);
      background-size: cover;
      background-position: center;
      font-family: Lato;
       color: white;
    }
    html{
      height: 100%;
    }
    #content{
      text-align: center;
      padding-top: 25%;
      text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
                   0px 8px 13px rgba(0,0,0,0.1),
                   0px 18px 23px rgba(0,0,0,0.1);
    }
    h1{
         font-weight: 700;
         font-size: 5em;
    }
    hr{
      width:400px;
        border-top: 1px solid #f8f8f8;
        border-bottom: 1px solid rgba(0,0,0,0.2)
    }
  </style>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">DesBird</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="products.php">Products<i class="fas fa-dove"></i><span class="sr-only">(current)</span></a></li>
        <li><a href="orders.php">Orders <i class="fas fa-file-invoice"></i></a></li>
      </ul>
      
      <ul class="nav navbar-nav navbar-right">
        <li><a href="customers.php">Customer <i class="fas fa-user"></i></a></li>
        <li><a href="staffs.php">Staff <i class="fas fa-user-tie"></i></a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="container">
<div class="row">
<div class="col-lg-12">
<div id="content">
<h1>DesBirds' Pet Shop</h1>
<h3>The only one-stop pet shop in Bangi.</h3>
<hr>
<button class="btn btn-default btn-lg"><i class="fas fa-paw"></i>Get Started!</button>
</div>
</div>
</div>  
</div>


</body>
</html>


