<?php
  include_once 'database.php';
    try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM tbl_products_a165433_pt2 WHERE fld_product_num = :pid");
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
      $pid = $_GET['pid'];
      $stmt->execute();
      $readrow = $stmt->fetch(PDO::FETCH_ASSOC);
      }
    catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $conn = null;
    ?>

    <div class="container-fluid">
      <div class="row">
        <div class="col-xs-12 col-sm-5 col-sm-offset-1 col-md-4 col-md-offset-2 well well-sm text-center">
         
         
            <img src="pictures/<?php echo $readrow['fld_product_num'] ?>.jpg" class="img-responsive">
        
          </div>
          <div class="col-xs-12 col-sm-5 col-md-4">
            <div class="panel panel-default">
            <div class="panel-heading"><strong>Product Details</strong></div>
            <div class="panel-body">
              Below are specifications of the product.
            </div>
            <table class="table">
              <tr>
                <td class="col-xs-4 col-sm-4 col-md-4"><strong>Product ID</strong></td>
                <td><?php echo $readrow['fld_product_num'] ?></td>
              </tr>
              <tr>
                <td><strong>Product Name</strong></td>
                <td><?php echo $readrow['fld_product_name'] ?></td>
              </tr>
              <tr>
                <td><strong>Price</strong></td>
                <td><?php echo $readrow['fld_product_price'] ?></td>
              </tr>
              <tr>
                <td><strong>Food</strong></td>
                <td><?php echo $readrow['fld_product_food'] ?></td>
              </tr>
              <tr>
                <td><strong>Cage Provided</strong></td>
                <td><?php echo $readrow['fld_product_cage'] ?></td>
              </tr>
              <tr>
                <td><strong>Description</strong></td>
                <td><?php echo $readrow['fld_product_description'] ?></td>
              </tr>
              <tr>
                <td><strong>Quantity</strong></td>
                <td><?php echo $readrow['fld_product_quantity'] ?></td>
              </tr>
            </table>
          </div>
        </div>
        </div>
      </div>