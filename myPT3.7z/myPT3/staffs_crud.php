<?php
 
include_once 'database.php';
 
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
//Create
if (isset($_POST['create'])) {
  if($_SESSION['user level']=='admin'){
    if($_POST['password']!=$_POST['confirmpassword']){
      $message = "You have enter the wrong password!";
      echo "<script type='text/javascript'>alert('$message');";
      echo "</script>";
    }else{

  try {
 
    $stmt = $conn->prepare("INSERT INTO tbl_staffs_a165433_pt2(fld_staff_num, fld_staff_name, fld_staff_contact, fld_staff_email,fld_staff_password,fld_staff_level ) VALUES(:sid, :name,
      :contact, :email, :password,:level)");
   
    $stmt->bindParam(':sid', $sid, PDO::PARAM_STR);
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':contact', $contact, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':password', $password, PDO::PARAM_STR);
    $stmt->bindParam(':level', $level, PDO::PARAM_STR);   
    $sid = $_POST['sid'];
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $level = $_POST['level']; 
        
    $stmt->execute();
Header("Location: staffs.php");

    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
}else{
    $message = "You have no right to make a change on this!";
    echo "<script type='text/javascript'>alert('$message');";
    echo "window.location.href = 'staffs.php';";
    echo "</script>";
  }
}





 
//Update
if (isset($_POST['update'])) {
  if($_SESSION['user level']=='admin'||$_SESSION['user level']=='supervisor'){
    if($_POST['password']!=$_POST['confirmpassword']){
      $message = "You have enter the wrong password!";
      echo "<script type='text/javascript'>alert('$message');";
      echo "</script>";
    }else{
   
  try {
 
    $stmt = $conn->prepare("UPDATE tbl_staffs_a165433_pt2 SET
      fld_staff_num = :sid, fld_staff_name = :name,
      fld_staff_contact = :contact, fld_staff_email = :email, fld_staff_level=:level,fld_staff_password=:password
      WHERE fld_staff_num = :oldsid");
   
    $stmt->bindParam(':sid', $sid, PDO::PARAM_STR);
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':contact', $contact, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':oldsid', $oldsid, PDO::PARAM_STR);
    $stmt->bindParam(':level', $level, PDO::PARAM_STR);
    $stmt->bindParam(':password', $password, PDO::PARAM_STR);
    $sid = $_POST['sid'];
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $oldsid = $_POST['oldsid'];
    $level=$_POST['level'];
    $password=$_POST['password'];
         
    $stmt->execute();
 
    header("Location: staffs.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
}
else{
    $message = "You have no right to make a change on this!";
    echo "<script type='text/javascript'>alert('$message');";
    echo "window.location.href = 'staffs.php';";
    echo "</script>";
  }

}
 
//Delete
if (isset($_GET['delete'])) {
  if($_SESSION['user level']=='admin'){
 
  try {
 
    $stmt = $conn->prepare("DELETE FROM tbl_staffs_a165433_pt2 where fld_staff_num = :sid");
   
    $stmt->bindParam(':sid', $sid, PDO::PARAM_STR);
       
    $sid = $_GET['delete'];
     
    $stmt->execute();
 
    header("Location: staffs.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}else{
    $message = "You have no right to make a change on this!";
    echo "<script type='text/javascript'>alert('$message');";
    echo "window.location.href = 'staffs.php';";
    echo "</script>";
  }
}
 







//Edit
if (isset($_GET['edit'])) {
  if($_SESSION['user level']=='admin' || $_SESSION['user level']=='supervisor'){
    try {
 
    $stmt = $conn->prepare("SELECT * FROM tbl_staffs_a165433_pt2  where fld_staff_num = :sid");
   
    $stmt->bindParam(':sid', $sid, PDO::PARAM_STR);
       
    $sid = $_GET['edit'];
     
    $stmt->execute();
 
    $editrow = $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
else{
    $message = "You have no right to make a change on this!";
    echo "<script type='text/javascript'>alert('$message');";
    echo "window.location.href = 'staffs.php';";
    echo "</script>";
  }
}
 
?>