<?php
 
$servername = "lrgs.ftsm.ukm.my";
$username = "a165433";
$password = "biggraygoat";
$dbname = "a165433";
 
?>