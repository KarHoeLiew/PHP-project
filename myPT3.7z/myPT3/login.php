<?php
	session_start();
	include_once 'database.php';

	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title> Desbirds : Login</title>
  <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
      
         
         <?php
			
			if(isset($_POST['id']) && isset($_POST['password'])){
				$query = "SELECT * FROM tbl_staffs_a165433_pt2 WHERE fld_staff_num = '".$_POST['id']."' AND fld_staff_password = '".$_POST['password']."'";
				$statement = $conn -> prepare($query);
				$statement -> execute();
				$result = $statement -> fetch();
				if(!empty($result)){
					$_SESSION['user level'] = $result["fld_staff_level"];
					$_SESSION['username'] = $result['fld_staff_name'];
					header("Location: index.php");
				}else{
					$message = "Incorrect id and password!";
					echo "<script type='text/javascript'>alert('$message');</script>";
				}
			}
         ?>
      <div class = "container" style="padding: 30px 250px;">
      
         <form action="login.php" method="post">
			<div class="form-group">
				<label>Enter your username and password</label>
				
			</div>
			<div class="form-group">
				<label for="staffid" class="col-sm-3 control-label">ID</label>
				<div class="col-sm-9">
					<input name="id" type="text" class="form-control" id="id" placeholder="Please insert your ID" required> <br>
				</div>
			</div>
			<div class="form-group">
				<label for="staffpassword" class="col-sm-3 control-label">Password</label>
				<div class="col-sm-9">
					<input name="password" type="password" class="form-control" id="password" placeholder="Please insert your password" required> <br>
				</div>
			</div>
			<div class="form-group">
				<button class = "btn btn-primary btn-block" type = "submit" name = "login" style="width: 75%;">Login</button>
			</div>
         </form>

      </div> 
      
   </body>
</html>